import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import datasets,transforms,utils
from PIL import Image
import argparse
###########
from model import CNNModel_FULL
from datasets import train_dataset, idx_to_class

def load_latest_checkpoint(model, checkpoints_dir):
    """
    从指定的 checkpoints 目录中检索最新模型文件并加载参数。
    """
    if not os.path.exists(checkpoints_dir):
        print(f"Checkpoints directory '{checkpoints_dir}' does not exist.")
        return model

    # 获取目录中的所有文件
    checkpoint_files = [f for f in os.listdir(checkpoints_dir) if f.endswith(".pth")]
    if not checkpoint_files:
        print(f"No checkpoint files found in '{checkpoints_dir}'.")
        return model

    # 按文件名排序（假设文件名中包含 epoch 信息或时间戳）
    checkpoint_files.sort(key=lambda x: os.path.getmtime(os.path.join(checkpoints_dir, x)), reverse=True)
    latest_checkpoint = checkpoint_files[0]
    latest_checkpoint_path = os.path.join(checkpoints_dir, latest_checkpoint)

if __name__ == "__main__":
    dataloader = DataLoader(train_dataset, batch_size=2, shuffle=True, num_workers=4)
    model = CNNModel_FULL(n_labels=15)
    
    # 检索并加载最新 checkpoint
    print("Try to load model from checkpoints")
    model = load_latest_checkpoint(model, "checkpoints")

    # 创建解析器
    parser = argparse.ArgumentParser(description="Please input num of epoches")
    parser.add_argument("--num_epochs", type=int, default=5, help="Number of training epochs (default: 5)")

    # 解析命令行参数
    args = parser.parse_args()
    num_epochs = args.num_epochs
    print(f"num_epoch = {num_epochs}")
    #num_epochs = 5
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=1e-4)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size= max(1, num_epochs // 10), gamma=0.9)
    model = model.to(device)
    model.train()
    for epoch in range(num_epochs): 
        running_loss = 0.0
        for batch_idx, (images, labels) in enumerate(dataloader, 1):  # 从 1 开始计数
            labels = labels.to(device)
            images = images.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 每 5 个 batch 打印一次损失
            if batch_idx % 5 == 0:
                current_lr = optimizer.param_groups[0]['lr']
                print(f"Epoch [{epoch+1}/{num_epochs}], Batch [{batch_idx}/{len(dataloader)}], Loss: {loss.item():.4f}, Learning Rate: {current_lr:.6f}")
            running_loss += loss.item()
        # 每个 epoch 的平均损失
        scheduler.step()
        epoch_loss = running_loss / len(dataloader)
        print(f"Epoch [{epoch+1}/{num_epochs}] completed, Average Loss: {epoch_loss:.4f}")
        if (epoch + 1) % max(1, num_epochs // 10) == 0: 
            checkpoint_path = os.path.join("checkpoints", f"model_epoch_{epoch+1}.pth")
            torch.save(model.state_dict(), checkpoint_path)
            print(f"Checkpoint saved: {checkpoint_path}")
    checkpoint_path = os.path.join("checkpoints", f"model_Final.pth")
    torch.save(model.state_dict(), checkpoint_path)
    print(f"Finish training,Checkpoint saved: {checkpoint_path}")